#ifndef FAVORITES_H
#define FAVORITES_H

#include <QFont>
#include <QIcon>
#include <QWidget>
#include <QPushButton>

class favorites : public QWidget
{
  Q_OBJECT
public:
  explicit favorites(QWidget *parent = nullptr);

signals:

public slots:

protected:

private:
  int SN;
  QPushButton* favoritesBtn;
  QList<QString> favoritesList;
};

#endif // FAVORITES_H
