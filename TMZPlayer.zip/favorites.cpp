#include "favorites.h"

favorites::favorites(QWidget *parent) : QWidget(parent)
{ 
  this->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
  favoritesBtn = new QPushButton(this);
  favoritesBtn->setFlat(true);
  favoritesBtn->setText(" 我的收藏");
//  favoritesBtn->setFixedHeight(35);
  this->setFixedSize(100, 30);
  QFont favoritesBtnFont = favoritesBtn->font();
  favoritesBtnFont.setPointSize(11);
  favoritesBtn->setStyleSheet("text-align: left;");
  favoritesBtn->setFont(favoritesBtnFont);
  QIcon likeIcon(":/image/image/musicform/btn_like_n.png");
  favoritesBtn->setIcon(likeIcon);
  favoritesBtn->setIconSize(QSize(20,20));

}
